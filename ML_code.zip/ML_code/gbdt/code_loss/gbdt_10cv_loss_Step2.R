# GBDT
# install.packages('gbm')
library(gbm)  
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "loss.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "loss"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)

# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 10) 
r2_train <- matrix(0, nrow = 1, ncol = 10)
rmse_test <- matrix(0, nrow = 1, ncol = 10)
r2_test <- matrix(0, nrow = 1, ncol = 10)


depth_r <- seq(1,8,1)
minobsinnode_c <- seq(1,10,1)

NR = length(depth_r)
NC = length(minobsinnode_c)


aver1_tr <- matrix(0, nrow = NR, ncol = NC)    
aver2_tr <- matrix(0, nrow = NR, ncol = NC)
aver1_te <- matrix(0, nrow = NR, ncol = NC)
aver2_te <- matrix(0, nrow = NR, ncol = NC)


# 生成输出文件夹
ad <- "## change the file path ##\\ML\\gbdt\\gbdt_loss_temp2\\"
dir.create(paste(ad, 'aver1_tr', sep =''))
dir.create(paste(ad, 'aver2_tr', sep =''))
dir.create(paste(ad, 'aver1_te', sep =''))
dir.create(paste(ad, 'aver2_te', sep =''))

ad1 = paste(ad, 'aver1_tr\\', sep ='')
ad2 = paste(ad, 'aver2_tr\\', sep ='')
ad3 = paste(ad, 'aver1_te\\', sep ='')
ad4 = paste(ad, 'aver2_te\\', sep ='')


tt = 1
t = 1
for (tt in c(1:50)){ # c(1:50)
# 交叉验证 + 网格搜索
  for (depth in depth_r){
    r = which(depth_r == depth)
    for (minobsinnode in minobsinnode_c){
      c = which(minobsinnode_c == minobsinnode)
      for (t in c(1:10)){
        set.seed(tt)
        par1 <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
        train1 <- dataset[par1==1,]
        test1 <- dataset[par1==2,]
        
        par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
        train <- train1[par != t,]
        test <- train1[par == t,]

        # 随机森林模型
        set.seed(tt)
        gbm1 <- gbm(loss ~., data = train,                                                                   # 需要更改             
                    var.monotone= rep(0,col-1),    # 0: no monotone restrictions  
                    distribution="gaussian",        # see the help for other choices  
                    n.trees=5900,                     # number of trees  
                    shrinkage=0.0025,                   # shrinkage or learning rate, 0.001 to 0.1 usually work  
                    interaction.depth=depth,    #要优化35678         # 1: additive model, 2: two-way interactions, etc.  
                    # bag.fraction = 0.5,     #默认         # subsampling fraction, 0.5 is probably best  
                    # train.fraction = 0.5,   #默认        # fraction of data for training, first train.fraction*N used for training  
                    n.minobsinnode = minobsinnode,     #要优化3579111315       # minimum total weight needed in each node  
                    # cv.folds = 10,                     # do 10-fold cross-validation  
                    keep.data=TRUE,                  # keep a copy of the dataset with the object  
                    verbose=FALSE,                   # don't print out progress  
                    n.cores=1)                        # 计算CPU核心数  
        # summary(gbm1)
        # plot(gbm1)
        # gbm.perf(gbm1, method = "cv")
        # gbm1$shrinkage
        # gbm1$ntree
        
        
        # 训练+测试---输出
        # 训练集
        ptrain <- predict(gbm1, train)
        rmse_train[1,t] <- rmse(train$loss,ptrain) # 训练集 RMSE                  # 需要更改
        
        R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
        R2a[,1] <- ptrain
        R2a[,2] <- train$loss                                                     # 需要更改
        R2a <- as.data.frame(R2a)
        names(R2a)[1] <- "ptrain"
        names(R2a)[2] <- "loss"                                                   # 需要更改
        la <- lm(loss ~.,R2a)                                                      # 需要更改
        r2_train[1,t] <- as.numeric(summary(la)["r.squared"])
        
        # 测试集
        ptest <- predict(gbm1, test)
        rmse_test[1,t] <- rmse(test$loss,ptest) # 测试集 RMSE                     # 需要更改
        
        R2b <- matrix(0, nrow = length(ptest), ncol = 2)
        R2b[,1] <- ptest
        R2b[,2] <- test$loss                                                      # 需要更改
        R2b <- as.data.frame(R2b)
        names(R2b)[1] <- "ptest"
        names(R2b)[2] <- "loss"                                                   # 需要更改
        lb <- lm(loss ~.,R2b)                                                      # 需要更改
        r2_test[1,t] <- as.numeric(summary(lb)["r.squared"])
        
        aver1_tr[r,c] = mean(rmse_train[1,])
        aver2_tr[r,c] = mean(r2_train[1,])
        aver1_te[r,c] = mean(rmse_test[1,])
        aver2_te[r,c] = mean(r2_test[1,])
        
        t = t + 1
      }
  
      
    write.csv(aver1_tr,paste(ad1,tt," aver1_tr.csv", sep = ''))
    write.csv(aver2_tr,paste(ad2,tt," aver2_tr.csv", sep = ''))
    write.csv(aver1_te,paste(ad3,tt," aver1_te.csv", sep = ''))
    write.csv(aver2_te,paste(ad4,tt," aver2_te.csv", sep = ''))
    
      
      
    }
  }
  print(paste('【已完成】', '循环：', tt, '/50', sep = '')) # , '部分：', t, '/10  ',
  
}
