# GBDT
# install.packages('gbm')
library(gbm)  
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "CTE.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "expansion"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row
l <- row

dataset <- data
head(dataset)


# create the output matrices
pred <- matrix(0, nrow = l, ncol = 1000)


a = 1
for (a in c(1:1000)){
  set.seed(a)
  par <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
  train <- dataset[par==1,]
  test <- dataset[par==2,]

  gbm1 <- gbm(expansion ~., data = train,                                                                   # 需要更改             
              var.monotone= rep(0,col-1),    # 0: no monotone restrictions  
              distribution="gaussian",        # see the help for other choices  
              n.trees=15000,                     # number of trees  
              shrinkage=0.025,                   # shrinkage or learning rate, 0.001 to 0.1 usually work  
              interaction.depth=9,    #要优化35678         # 1: additive model, 2: two-way interactions, etc.  
              # bag.fraction = 0.5,     #默认         # subsampling fraction, 0.5 is probably best  
              # train.fraction = 0.5,   #默认        # fraction of data for training, first train.fraction*N used for training  
              n.minobsinnode = 4,     #要优化3579111315       # minimum total weight needed in each node  
              # cv.folds = 10,                     # do 10-fold cross-validation  
              keep.data=TRUE,                  # keep a copy of the dataset with the object  
              verbose=FALSE,                   # don't print out progress  
              n.cores=1)                        # 计算CPU核心数  
  # summary(gbm1)
  

  # prediction of the testing set (did not involve in the current model training)
  p <- predict(ann1, test)
  pp <- as.matrix(p)
  k=1
  for (k in c(1:l)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] = NA}
    
    k = k+1
  }
  
  print(paste('已完成：', a))
  a = a+1
}

ad <- "## change the file path ##"                     # change the ##output file path## into the real output file path

write.csv(pred, paste(ad, "gbdt_expansion.csv"))



