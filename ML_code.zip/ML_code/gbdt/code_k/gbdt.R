# GBDT
# install.packages('gbm')
library(gbm)  
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "permittivity.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "permittivity"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)


# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 1000)
r2_train <- matrix(0, nrow = 1, ncol = 1000)
rmse_test <- matrix(0, nrow = 1, ncol = 1000)
r2_test <- matrix(0, nrow = 1, ncol = 1000)
pred <- matrix(0, nrow = L, ncol = 1000)
pred2 <- matrix(0, nrow = L, ncol = 1000)

a = 1
for (a in c(1:1000)){
  set.seed(a)
  
  ind<-sample(2,nrow(dataset),replace = T,prob = c(0.7,0.3))
  trainset<-dataset[ind == 1,]
  testset<-dataset[ind == 2,]

  gbm1 <- gbm(permittivity ~., data = trainset,                                                                   # 需要更改             
              var.monotone= rep(0,col-1),    # 0: no monotone restrictions  
              distribution="gaussian",        # see the help for other choices  
              n.trees=3800,                     # number of trees  
              shrinkage=0.0075,                   # shrinkage or learning rate, 0.001 to 0.1 usually work  
              interaction.depth=3,    #要优化35678         # 1: additive model, 2: two-way interactions, etc.  
              n.minobsinnode = 1,     #要优化3579111315       # minimum total weight needed in each node  
              keep.data=TRUE,                  # keep a copy of the dataset with the object  
              verbose=FALSE,                   # don't print out progress  
              n.cores=1)                        # 计算CPU核心数  
  # summary(gbm1)
  

  ### training and testing results ###
  ptrain <- predict(gbm1, trainset)
  rmse_train[1,a] <- rmse(trainset$permittivity,ptrain) # RMSE of the training data set
  
  R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
  R2a[,1] <- ptrain
  R2a[,2] <- trainset$permittivity
  R2a <- as.data.frame(R2a)
  names(R2a)[1] <- "ptrain"
  names(R2a)[2] <- "permittivity"
  la <- lm(permittivity~.,R2a)
  r2_train[1,a] <- as.numeric(summary(la)["r.squared"]) # R2 of the training data set
  
  ptest <- predict(gbm1, testset)
  rmse_test[1,a] <- rmse(testset$permittivity,ptest) # RMSE of the testing data set
  
  R2b <- matrix(0, nrow = length(ptest), ncol = 2)
  R2b[,1] <- ptest
  R2b[,2] <- testset$permittivity
  R2b <- as.data.frame(R2b)
  names(R2b)[1] <- "ptest"
  names(R2b)[2] <- "permittivity"
  lb <- lm(permittivity~.,R2b)
  r2_test[1,a] <- as.numeric(summary(lb)["r.squared"]) # R2 of the testing data set

  
  # prediction of the testing set (did not involve in the current model training)
  p <- predict(gbm1, testset)
  pp <- data.frame(p, row.names = row.names(testset))
  pp <- as.matrix(pp)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] =NA}
    
    k = k+1
  }
  
  # prediction of the training set (did not involve in the current model training)
  p <- predict(gbm1, trainset)
  pp <- data.frame(p, row.names = row.names(trainset))
  pp <- as.matrix(pp)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred2[k,a] = pp[row.names(pp) == k]}
    else {pred2[k,a] =NA}
    
    k = k+1
  }
  
  print(paste('已完成：', a))
  a = a+1
}

ad <- "## change the file path ##"                     # change the ##output file path## into the real output file path

write.csv(rmse_train, paste(ad, "rmse_train.csv"))
write.csv(r2_train, paste(ad, "r2_train.csv"))
write.csv(rmse_test, paste(ad, "rmse_test.csv"))
write.csv(r2_test, paste(ad, "r2_test.csv"))
write.csv(pred, paste(ad, "gbdt_pred_test.csv"))
write.csv(pred2, paste(ad, "gbdt_pred_train.csv"))

### Further processing was done by EXCEL.



