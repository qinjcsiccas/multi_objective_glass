# install.packages('glmnet')
library(glmnet)
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "YM.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "modulus"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)

last_c = length(dataset)

# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 10) 
r2_train <- matrix(0, nrow = 1, ncol = 10)
rmse_test <- matrix(0, nrow = 1, ncol = 10)
r2_test <- matrix(0, nrow = 1, ncol = 10)


bc = 2
nl_range = seq(2, 30, bc)

NR = 1
NC = length(nl_range)

aver1_tr <- matrix(0, nrow = NR, ncol = NC)    
aver2_tr <- matrix(0, nrow = NR, ncol = NC)
aver1_te <- matrix(0, nrow = NR, ncol = NC)
aver2_te <- matrix(0, nrow = NR, ncol = NC)

# 生成输出文件夹
ad <- "## change the file path ##\\ML\\lasso\\lasso_modulus_temp\\"
dir.create(paste(ad, 'aver1_tr', sep =''))
dir.create(paste(ad, 'aver2_tr', sep =''))
dir.create(paste(ad, 'aver1_te', sep =''))
dir.create(paste(ad, 'aver2_te', sep =''))

ad1 = paste(ad, 'aver1_tr\\', sep ='')
ad2 = paste(ad, 'aver2_tr\\', sep ='')
ad3 = paste(ad, 'aver1_te\\', sep ='')
ad4 = paste(ad, 'aver2_te\\', sep ='')

# grid search method + 10 fold cross-validation
tt = 1
t = 1
for (tt in c(1:50)){
  for (nl in nl_range){ 
    c = which(nl == nl_range)
    for (t in c(1:10)){
      set.seed(tt)
      par1 <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
      train1 <- dataset[par1==1,]
      test1 <- dataset[par1==2,]
      
      par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
      train <- train1[par != t,]
      test <- train1[par == t,]
      
  
      lasso <- glmnet(x = train[,-last_c], y = train[,last_c], nlambda = nl, 
                      family='gaussian', intercept = F, alpha=1) 
      
  
      
      ### training and testing results ###
  
      ptrain_m <- predict(lasso, newx = data.matrix(train[,-last_c]), type = "response")
      dim(ptrain_m)
      ptrain <- ptrain_m[,dim(ptrain_m)[2]]
      rmse_train[1,t] <- rmse(train$modulus,ptrain) # RMSE of the training data set
      
      R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
      R2a[,1] <- ptrain
      R2a[,2] <- train$modulus
      R2a <- as.data.frame(R2a)
      names(R2a)[1] <- "ptrain"
      names(R2a)[2] <- "modulus"
      la <- lm(modulus~.,R2a)
      r2_train[1,t] <- as.numeric(summary(la)["r.squared"]) # R2 of the training data set
      
      
      ptest_m <- predict(lasso, newx = data.matrix(test[,-last_c]), type = "response")
      dim(ptest_m)
      ptest <- ptest_m[,dim(ptest_m)[2]]
      rmse_test[1,t] <- rmse(test$modulus,ptest) # RMSE of the testing data set
      
      R2b <- matrix(0, nrow = length(ptest), ncol = 2)
      R2b[,1] <- ptest
      R2b[,2] <- test$modulus
      R2b <- as.data.frame(R2b)
      names(R2b)[1] <- "ptest"
      names(R2b)[2] <- "modulus"
      lb <- lm(modulus~.,R2b)
      r2_test[1,t] <- as.numeric(summary(lb)["r.squared"]) # R2 of the testing data set
      
  
      aver1_tr[1,c] = mean(rmse_train[1,])
      aver2_tr[1,c] = mean(r2_train[1,])
      aver1_te[1,c] = mean(rmse_test[1,])
      aver2_te[1,c] = mean(r2_test[1,])
      
      
      t = t + 1
    }
  }

  write.csv(aver1_tr,paste(ad1,tt," aver1_tr.csv", sep = ''))
  write.csv(aver2_tr,paste(ad2,tt," aver2_tr.csv", sep = ''))
  write.csv(aver1_te,paste(ad3,tt," aver1_te.csv", sep = ''))
  write.csv(aver2_te,paste(ad4,tt," aver2_te.csv", sep = ''))
  
  
  print(paste('【已完成】', '循环：', tt, '/50', sep = '')) # , '部分：', t, '/10  ',
  
  
  tt = tt + 1
  
}

### Further processing was done by EXCEL.














