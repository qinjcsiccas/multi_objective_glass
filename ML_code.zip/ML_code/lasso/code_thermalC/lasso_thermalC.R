# install.packages('glmnet')
library(glmnet)
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "TC.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "thermalC"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)


last_c = length(dataset)

# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 1000)
r2_train <- matrix(0, nrow = 1, ncol = 1000)
rmse_test <- matrix(0, nrow = 1, ncol = 1000)
r2_test <- matrix(0, nrow = 1, ncol = 1000)
pred <- matrix(0, nrow = L, ncol = 1000)
pred2 <- matrix(0, nrow = L, ncol = 1000)

a = 1
for (a in c(1:1000)){
  set.seed(a)
  
  ind<-sample(2,nrow(dataset),replace = T,prob = c(0.7,0.3))
  trainset<-dataset[ind == 1,]
  testset<-dataset[ind == 2,]
  
  lasso <- glmnet(x = trainset[,-last_c], y = trainset[,last_c], nlambda = 580, 
                  family='gaussian', intercept = F, alpha=1)                      # 计算CPU核心数  
  # summary(gbm1)
  

  ### training and testing results ###
  ptrain_m <- predict(lasso, newx = data.matrix(trainset[,-last_c]), type = "response")
  dim(ptrain_m)
  ptrain <- ptrain_m[,dim(ptrain_m)[2]]
  rmse_train[1,a] <- rmse(trainset$thermalC,ptrain) # RMSE of the training data set
  
  R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
  R2a[,1] <- ptrain
  R2a[,2] <- trainset$thermalC
  R2a <- as.data.frame(R2a)
  names(R2a)[1] <- "ptrain"
  names(R2a)[2] <- "thermalC"
  la <- lm(thermalC~.,R2a)
  r2_train[1,a] <- as.numeric(summary(la)["r.squared"]) # R2 of the training data set
  
  
  
  ptest_m <- predict(lasso, newx = data.matrix(testset[,-last_c]), type = "response")
  dim(ptest_m)
  ptest <- ptest_m[,dim(ptest_m)[2]]
  rmse_test[1,a] <- rmse(testset$thermalC,ptest) # RMSE of the testing data set
  
  R2b <- matrix(0, nrow = length(ptest), ncol = 2)
  R2b[,1] <- ptest
  R2b[,2] <- testset$thermalC
  R2b <- as.data.frame(R2b)
  names(R2b)[1] <- "ptest"
  names(R2b)[2] <- "thermalC"
  lb <- lm(thermalC~.,R2b)
  r2_test[1,a] <- as.numeric(summary(lb)["r.squared"]) # R2 of the testing data set
  
  
  
  

  # prediction of the testing set (did not involve in the current model training)
  p <- ptest
  pp <- data.frame(p, row.names = row.names(testset))
  pp <- as.matrix(pp)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] =NA}
    
    k = k+1
  }
  
  # prediction of the training set (involve in the current model training)
  p <- ptrain
  pp <- data.frame(p, row.names = row.names(trainset))
  pp <- as.matrix(pp)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred2[k,a] = pp[row.names(pp) == k]}
    else {pred2[k,a] =NA}
    
    k = k+1
  }
  
  print(paste('已完成：', a))
  a = a+1
}

ad <- "## change the file path ##"                     # change the ##output file path## into the real output file path

write.csv(rmse_train, paste(ad, "rmse_train.csv"))
write.csv(r2_train, paste(ad, "r2_train.csv"))
write.csv(rmse_test, paste(ad, "rmse_test.csv"))
write.csv(r2_test, paste(ad, "r2_test.csv"))
write.csv(pred, paste(ad, "lasso_pred_test.csv"))
write.csv(pred2, paste(ad, "lasso_pred_train.csv"))

### Further processing was done by EXCEL.


























