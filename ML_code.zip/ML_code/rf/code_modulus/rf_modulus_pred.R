### random forest model ###

library(Metrics)
library(randomForest)

path0 <- "## change the file path ##"
file_name <- "YM.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "modulus"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row
l <- row

dataset <- data
head(dataset)


# create the output matrices
pred <- matrix(0, nrow = l, ncol = 1000)

a = 1
for (a in c(1:1000)){
  set.seed(a)
  par <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
  train <- dataset[par==1,]
  test <- dataset[par==2,]

  set.seed(a)
  rf <- randomForest(modulus ~., trainset, ntree = 850, mtry = 3, nodesize = 1)
  # summary(rf)

  # prediction of the testing set (did not involve in the current model training)
  p <- predict(rf, test)
  pp <- as.matrix(p)
  k=1
  for (k in c(1:l)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] = NA}
    
    k = k+1
  }
  
  print(paste('已完成：', a))
  a = a+1
}


ad <- "## change the file path ##"                      # change the ##output file path## into the real output file path

write.csv(pred, paste(ad, "ann_modulus.csv"))




### Further processing was done by EXCEL.



