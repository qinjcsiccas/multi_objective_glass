### hyperparameter optimization of random forest model ###

library(Metrics)
library(randomForest)

path0 <- "## change the file path ##"
file_name <- "loss.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "loss"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)


kfold = 10 # 五折交叉验证

# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = kfold) 
r2_train <- matrix(0, nrow = 1, ncol = kfold)
rmse_test <- matrix(0, nrow = 1, ncol = kfold)
r2_test <- matrix(0, nrow = 1, ncol = kfold)




nodesize_range = seq(0, 8, 1)
NC = length(nodesize_range)

aver1_tr <- matrix(0, nrow = 1, ncol = NC)    
aver2_tr <- matrix(0, nrow = 1, ncol = NC)
aver1_te <- matrix(0, nrow = 1, ncol = NC)
aver2_te <- matrix(0, nrow = 1, ncol = NC)



# 生成输出文件夹
ad <- "## change the file path ##\\ML\\rf\\rf_loss_temp_2\\"
dir.create(paste(ad, 'aver1_tr', sep =''))
dir.create(paste(ad, 'aver2_tr', sep =''))
dir.create(paste(ad, 'aver1_te', sep =''))
dir.create(paste(ad, 'aver2_te', sep =''))

ad1 = paste(ad, 'aver1_tr\\', sep ='')
ad2 = paste(ad, 'aver2_tr\\', sep ='')
ad3 = paste(ad, 'aver1_te\\', sep ='')
ad4 = paste(ad, 'aver2_te\\', sep ='')

# grid search method + 10 fold cross-validation
tt = 1
t = 1

# optimized ntree + mtry
ntree = 750
mtry = 2

for (tt in c(1:50)){
  for (nodesize in nodesize_range){  
    for (t in c(1:10)){
      set.seed(tt)
      par1 <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3)) # random sampling
      train1 <- dataset[par1==1,]
      test1 <- dataset[par1==2,]
      
      par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
      train <- train1[par != t,]
      test <- train1[par == t,]
      
      rf <- randomForest(loss ~., train, ntree = ntree, mtry = mtry, nodesize = nodesize)
      # summary(rf) 

      ### training and testing results ###
      ptrain <- predict(rf, train)
      rmse_train[1,t] <- rmse(train$loss,ptrain) # RMSE of the training data set
      
      R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
      R2a[,1] <- ptrain
      R2a[,2] <- train$loss
      R2a <- as.data.frame(R2a)
      names(R2a)[1] <- "ptrain"
      names(R2a)[2] <- "loss"
      la <- lm(loss~.,R2a)
      r2_train[1,t] <- as.numeric(summary(la)["r.squared"]) # R2 of the training data set
      
      ptest <- predict(rf, test)
      rmse_test[1,t] <- rmse(test$loss,ptest) # RMSE of the testing data set
      
      R2b <- matrix(0, nrow = length(ptest), ncol = 2)
      R2b[,1] <- ptest
      R2b[,2] <- test$loss
      R2b <- as.data.frame(R2b)
      names(R2b)[1] <- "ptest"
      names(R2b)[2] <- "loss"
      lb <- lm(loss~.,R2b)
      r2_test[1,t] <- as.numeric(summary(lb)["r.squared"]) # R2 of the testing data set
      
      ns_col = nodesize - nodesize_range[1] + 1
      
      aver1_tr[1,ns_col] = mean(rmse_train[1,])
      aver2_tr[1,ns_col] = mean(r2_train[1,])
      aver1_te[1,ns_col] = mean(rmse_test[1,])
      aver2_te[1,ns_col] = mean(r2_test[1,])
        
        t = t + 1
    }
}

  

  write.csv(aver1_tr,paste(ad1,tt,"aver1_tr.csv"))
  write.csv(aver2_tr,paste(ad2,tt,"aver2_tr.csv"))
  write.csv(aver1_te,paste(ad3,tt,"aver1_te.csv"))
  write.csv(aver2_te,paste(ad4,tt,"aver2_te.csv"))
  
  print(paste('【已完成】', '循环：', tt, '/50', sep = '')) # , '部分：', t, '/10  ',
  
  tt = tt + 1
  
}

### Further processing was done by EXCEL.








