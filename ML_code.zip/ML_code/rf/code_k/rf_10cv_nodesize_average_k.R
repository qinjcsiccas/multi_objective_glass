library(stringr)

################
# 批量读取cif文件
path <- "## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver2_tr\\" ##文件目录

fileNames <- dir(path)  ##获取该路径下的文件名
filePath <- sapply(fileNames, function(x){ 
  paste(path,x,sep='/')})   ##生成读取文件路径
data <- lapply(filePath, function(x){
  read.csv(x, header = T)})  ##读取数据，结果为list
str(data)

data = data[c(1:50)]

NR = dim(data[[1]])[1]
NC = dim(data[[1]])[2] - 1
L = length(data)

result <- matrix(0, nrow = NR, ncol = NC)
temp <- matrix(0, nrow = 1, ncol = L)

i = 1
j = 1
f = 1

  for (j in c(1:NC)){
    for (f in c(1:L)){
      temp[1,f] <- data[[f]][i,j+1]
    }
    
    result[i,j] <- mean(temp)
    
  }
  
write.csv(result,paste("## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver2_tr.csv", sep=''))


################
# 批量读取cif文件
path <- "## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver1_tr\\" ##文件目录

fileNames <- dir(path)  ##获取该路径下的文件名
filePath <- sapply(fileNames, function(x){ 
  paste(path,x,sep='/')})   ##生成读取文件路径
data <- lapply(filePath, function(x){
  read.csv(x, header = T)})  ##读取数据，结果为list
str(data)

data = data[c(1:50)]

NR = dim(data[[1]])[1]
NC = dim(data[[1]])[2] - 1
L = length(data)

result <- matrix(0, nrow = NR, ncol = NC)
temp <- matrix(0, nrow = 1, ncol = L)

i = 1
j = 1
f = 1

for (j in c(1:NC)){
  for (f in c(1:L)){
    temp[1,f] <- data[[f]][i,j+1]
  }
  
  result[i,j] <- mean(temp)
  
}

write.csv(result,paste("## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver1_tr.csv", sep=''))



################
# 批量读取cif文件
path <- "## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver2_te\\" ##文件目录

fileNames <- dir(path)  ##获取该路径下的文件名
filePath <- sapply(fileNames, function(x){ 
  paste(path,x,sep='/')})   ##生成读取文件路径
data <- lapply(filePath, function(x){
  read.csv(x, header = T)})  ##读取数据，结果为list
str(data)

data = data[c(1:50)]

NR = dim(data[[1]])[1]
NC = dim(data[[1]])[2] - 1
L = length(data)

result <- matrix(0, nrow = NR, ncol = NC)
temp <- matrix(0, nrow = 1, ncol = L)

i = 1
j = 1
f = 1

for (j in c(1:NC)){
  for (f in c(1:L)){
    temp[1,f] <- data[[f]][i,j+1]
  }
  
  result[i,j] <- mean(temp)
  
}

write.csv(result,paste("## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver2_te.csv", sep=''))



################
# 批量读取cif文件
path <- "## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver1_te\\" ##文件目录

fileNames <- dir(path)  ##获取该路径下的文件名
filePath <- sapply(fileNames, function(x){ 
  paste(path,x,sep='/')})   ##生成读取文件路径
data <- lapply(filePath, function(x){
  read.csv(x, header = T)})  ##读取数据，结果为list
str(data)

data = data[c(1:50)]

NR = dim(data[[1]])[1]
NC = dim(data[[1]])[2] - 1
L = length(data)

result <- matrix(0, nrow = NR, ncol = NC)
temp <- matrix(0, nrow = 1, ncol = L)

i = 1
j = 1
f = 1

for (j in c(1:NC)){
  for (f in c(1:L)){
    temp[1,f] <- data[[f]][i,j+1]
  }
  
  result[i,j] <- mean(temp)
  
}

write.csv(result,paste("## change the file path ##\\ML\\rf\\rf_10GHz_temp_2\\aver1_te.csv", sep=''))









