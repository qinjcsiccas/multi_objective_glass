### xgboost model ###
# install.packages("xgboost")
library(xgboost)
library(Metrics)

path0 <- "## change the file path ##\\ML\\【data】\\multi-property\\"
file_name <- "CTE.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "expansion"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)

# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 10) 
r2_train <- matrix(0, nrow = 1, ncol = 10)
rmse_test <- matrix(0, nrow = 1, ncol = 10)
r2_test <- matrix(0, nrow = 1, ncol = 10)


depth_step = 1
depth_c <- seq(1, 20, depth_step)

NR = 1
s_row = 1
NC = length(depth_c)


aver1_tr <- matrix(0, nrow = NR, ncol = NC)    
aver2_tr <- matrix(0, nrow = NR, ncol = NC)
aver1_te <- matrix(0, nrow = NR, ncol = NC)
aver2_te <- matrix(0, nrow = NR, ncol = NC)


# 生成输出文件夹
ad <- "## change the file path ##\\ML\\xgb\\xgb_expansion_temp_2\\"
dir.create(paste(ad, 'aver1_tr', sep =''))
dir.create(paste(ad, 'aver2_tr', sep =''))
dir.create(paste(ad, 'aver1_te', sep =''))
dir.create(paste(ad, 'aver2_te', sep =''))

ad1 = paste(ad, 'aver1_tr\\', sep ='')
ad2 = paste(ad, 'aver2_tr\\', sep ='')
ad3 = paste(ad, 'aver1_te\\', sep ='')
ad4 = paste(ad, 'aver2_te\\', sep ='')


# grid search method + 10 fold cross-validation
tt = 1
t = 1
for (tt in c(1:50)){
  # create the output matrices
  rmse_train <- matrix(0, nrow = 1, ncol = 10) 
  r2_train <- matrix(0, nrow = 1, ncol = 10)
  rmse_test <- matrix(0, nrow = 1, ncol = 10)
  r2_test <- matrix(0, nrow = 1, ncol = 10)
  
  aver1_tr <- matrix(0, nrow = NR, ncol = NC)    
  aver2_tr <- matrix(0, nrow = NR, ncol = NC)
  aver1_te <- matrix(0, nrow = NR, ncol = NC)
  aver2_te <- matrix(0, nrow = NR, ncol = NC)
  

  for (depth in depth_c){  
    s_col = which(depth == depth_c)
      for (t in c(1:10)){
        set.seed(tt)
        par1 <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
        train1 <- dataset[par1==1,]
        test1 <- dataset[par1==2,]
        
        par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
        train <- train1[par != t,]
        test <- train1[par == t,]
        
        # modeling
        set.seed(tt)
        x = model.matrix(expansion ~., train)[, -1]
        data_train = xgb.DMatrix(x, label = as.numeric(train$expansion))
        
        y = model.matrix(expansion ~., test)[, -1]
        data_test = xgb.DMatrix(y, label = as.numeric(test$expansion))
        
        ###############################
        param = list(eta = 0.25, # [0,1]
                     gamma = 2, # [0,]
                     max_depth = depth, # [0,]
                     # subsample = 1, # (0,1]
                     objective = "reg:squarederror")
        
        xgb_reg = xgb.train(param, data_train, nrounds = 200)
        
        
        # help(nnet)
        # summary(xgb_reg)
        

        ### training and testing results ###
        ptrain <- predict(xgb_reg, data_train)
        rmse_train[1,t] <- rmse(train$expansion,ptrain)           # RMSE of the training data set
        
        R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
        R2a[,1] <- ptrain
        R2a[,2] <- train$expansion                                                     
        R2a <- as.data.frame(R2a)
        names(R2a)[1] <- "ptrain"
        names(R2a)[2] <- "expansion"                                                   
        la <- lm(expansion~.,R2a)                                                      
        r2_train[1,t] <- as.numeric(summary(la)["r.squared"])       # R2 of the training data set
        

        ptest <- predict(xgb_reg, data_test)
        rmse_test[1,t] <- rmse(test$expansion,ptest)              # RMSE of the testing data set
        
        R2b <- matrix(0, nrow = length(ptest), ncol = 2)
        R2b[,1] <- ptest
        R2b[,2] <- test$expansion                                                     
        R2b <- as.data.frame(R2b)
        names(R2b)[1] <- "ptest"
        names(R2b)[2] <- "expansion"                                                  
        lb <- lm(expansion~.,R2b)                                                      
        r2_test[1,t] <- as.numeric(summary(lb)["r.squared"])         # R2 of the testing data set
        
        
        aver1_tr[s_row,s_col] = mean(rmse_train[1,])
        aver2_tr[s_row,s_col] = mean(r2_train[1,])
        aver1_te[s_row,s_col] = mean(rmse_test[1,])
        aver2_te[s_row,s_col] = mean(r2_test[1,])
        
        # print(paste('【已完成】', '十折交叉验证：', t, '/10', sep = '')) # , '部分：', t, '/10  ',
        
        t = t + 1
      }


    write.csv(aver1_tr,paste(ad1,tt," aver1_tr.csv", sep = ''))
    write.csv(aver2_tr,paste(ad2,tt," aver2_tr.csv", sep = ''))
    write.csv(aver1_te,paste(ad3,tt," aver1_te.csv", sep = ''))
    write.csv(aver2_te,paste(ad4,tt," aver2_te.csv", sep = ''))
    
    
  }

print(paste('【已完成】', '循环：', tt, '/50', sep = '')) # , '部分：', t, '/10  ',
  
}


### Further processing was done by EXCEL.


