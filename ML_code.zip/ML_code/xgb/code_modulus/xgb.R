### xgboost model ###
# install.packages("xgboost")
library(xgboost)
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "YM.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "modulus"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)


# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 1000)
r2_train <- matrix(0, nrow = 1, ncol = 1000)
rmse_test <- matrix(0, nrow = 1, ncol = 1000)
r2_test <- matrix(0, nrow = 1, ncol = 1000)
pred <- matrix(0, nrow = L, ncol = 1000)
pred2 <- matrix(0, nrow = L, ncol = 1000)

a = 1
for (a in c(1:1000)){
  set.seed(a)
  par <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
  train <- dataset[par==1,]
  test <- dataset[par==2,]

  set.seed(a)
  ###############################
  x = model.matrix(modulus ~., train)[, -1]
  data_train = xgb.DMatrix(x, label = as.numeric(train$modulus))
  
  y = model.matrix(modulus ~., test)[, -1]
  data_test = xgb.DMatrix(y, label = as.numeric(test$modulus))
  
  ###############################
  param = list(eta = 0.15, # [0,1]
               gamma = 32, # [0,]
               max_depth = 5, # [0,]
               # subsample = 1, # (0,1]
               objective = "reg:squarederror")

  xgb_reg = xgb.train(param, data_train, nrounds = 200)
  


  ### training and testing results ###
  ptrain <- predict(xgb_reg, data_train)
  rmse_train[1,a] <- rmse(train$modulus,ptrain)           # RMSE of the training data set

  R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
  R2a[,1] <- ptrain
  R2a[,2] <- train$modulus                                                     
  R2a <- as.data.frame(R2a)
  names(R2a)[1] <- "ptrain"
  names(R2a)[2] <- "modulus"                                                   
  la <- lm(modulus~.,R2a)                                                     
  r2_train[1,a] <- as.numeric(summary(la)["r.squared"])       # R2 of the training data set
  

  ptest <- predict(xgb_reg, data_test)
  rmse_test[1,a] <- rmse(test$modulus,ptest)              # RMSE of the testing data set
  
  R2b <- matrix(0, nrow = length(ptest), ncol = 2)
  R2b[,1] <- ptest
  R2b[,2] <- test$modulus                                                     
  R2b <- as.data.frame(R2b)
  names(R2b)[1] <- "ptest"
  names(R2b)[2] <- "modulus"                                                   
  lb <- lm(modulus~.,R2b)                                                      
  r2_test[1,a] <- as.numeric(summary(lb)["r.squared"])         # R2 of the testing data set
  
  
  # prediction of the testing set (did not involve in the current model training)
  pp <- as.matrix(ptest)
  ppp <- as.matrix(test)
  
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(ppp)) {pred[k,a] = pp[which(row.names(ppp) == k)]}
    else {pred[k,a] =NA}
    
    k = k+1
  }
  
  pp <- as.matrix(ptrain)
  ppp <- as.matrix(train)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(ppp)) {pred2[k,a] = pp[which(row.names(ppp) == k)]}
    else {pred2[k,a] =NA}
    
    k = k+1
  }
  print(paste('已完成：', a))
  
  a = a+1
}


ad <- "## change the file path ##"                     # change the ##output file path## into the real output file path

write.csv(rmse_train,paste(ad, "rmse_train.csv"))
write.csv(r2_train,paste(ad, "r2_train.csv"))
write.csv(rmse_test,paste(ad, "rmse_test.csv"))
write.csv(r2_test,paste(ad, "r2_test.csv"))
write.csv(pred, paste(ad, "xgb_pred_test.csv"))
write.csv(pred2, paste(ad, "xgb_pred_train.csv"))


### Further processing was done by EXCEL.
