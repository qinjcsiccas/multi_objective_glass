library(Metrics)

path0 <- "## change the file path ##"
file_name <- "CTE.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "expansion"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)

# 定义输出矩阵
rmse_train <- matrix(0, nrow = 1, ncol = 1000)
r2_train <- matrix(0, nrow = 1, ncol = 1000)
rmse_test <- matrix(0, nrow = 1, ncol = 1000)
r2_test <- matrix(0, nrow = 1, ncol = 1000)
pred <- matrix(0, nrow = L, ncol = 1000)
pred2 <- matrix(0, nrow = L, ncol = 1000)


a = 1
for (a in c(1:1000)){
  set.seed(a)
  
  ind<-sample(2,nrow(dataset),replace = T,prob = c(0.7,0.3))
  trainset<-dataset[ind == 1,]
  testset<-dataset[ind == 2,]
  
  temp.lm <- lm(expansion ~., data = trainset)
  

  # 训练+测试---输出
  ptrain <- predict(temp.lm, trainset)
  rmse_train[1,a] <- rmse(trainset$expansion,ptrain) # 训练集 RMSE                           # 需要更改
  r2_train[1,a] <- as.numeric(summary(temp.lm)["r.squared"]) # 训练集 R2
  
  ptest <- predict(temp.lm, testset)
  # 用线性模型算出R2
  R2t <- matrix(0, nrow = length(ptest), ncol = 2)
  R2t[,1] <- ptest
  R2t[,2] <- testset$expansion                                                               # 需要更改
  R2t <- as.data.frame(R2t)
  names(R2t)[1] <- "ptest"
  names(R2t)[2] <- "expansion"                                                            # 需要更改
  
  l <- lm(expansion~.,R2t) 
  rmse_test[1,a] <- rmse(testset$expansion,ptest) # 测试集 RMSE
  r2_test[1,a] <- as.numeric(summary(l)["r.squared"]) # 测试集 R2
  
  
  # 预测值
  pp <- as.matrix(ptest)
  # 测试集，未参与建模的数据，赋值
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] =NA}
    
    k = k+1
  }
  
  # 预测值
  pp <- as.matrix(ptrain)
  # 测试集，未参与建模的数据，赋值
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred2[k,a] = pp[row.names(pp) == k]}
    else {pred2[k,a] =NA}
    
    k = k+1
  }
  
  print(paste('已完成：', a))
  a = a+1
}

path_out <- '## change the file path ##'

write.csv(rmse_train, paste(path_out, "rmse_train.csv", sep = ''))
write.csv(r2_train, paste(path_out, "r2_train.csv", sep = ''))
write.csv(rmse_test, paste(path_out, "rmse_test.csv", sep = ''))
write.csv(r2_test, paste(path_out, "r2_test.csv", sep = ''))

write.csv(pred, paste(path_out, "lr_pred_test.csv", sep = ''))
write.csv(pred2, paste(path_out, "lr_pred_train.csv", sep = ''))


