### support vector regression (with radial basis function as kernel) model ###

library(Metrics)
library(e1071)

path0 <- "## change the file path ##"
file_name <- "permittivity.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "permittivity"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)


# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 1000)
r2_train <- matrix(0, nrow = 1, ncol = 1000)
rmse_test <- matrix(0, nrow = 1, ncol = 1000)
r2_test <- matrix(0, nrow = 1, ncol = 1000)
pred <- matrix(0, nrow = L, ncol = 1000)
pred2 <- matrix(0, nrow = L, ncol = 1000)


# run the model (random sampling + model training and testing) for 1000 times with different seeds
a = 1
for (a in c(1:1000)){
  set.seed(a)
  # random sampling
  ind<-sample(2,nrow(dataset),replace = T,prob = c(0.7,0.3))
  trainset<-dataset[ind == 1,]
  testset<-dataset[ind == 2,]
  
  temp.svr <- svm(permittivity ~., data = trainset, cost = 2^2, gamma = 0.04, 
             kernel ="radial") 

  ### training and testing results ###
  ptrain <- predict(temp.svr, trainset)
  rmse_train[1,a] <- rmse(trainset$permittivity,ptrain) # RMSE of the training data set     
  
  R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
  R2a[,1] <- ptrain
  R2a[,2] <- trainset$permittivity
  R2a <- as.data.frame(R2a)
  names(R2a)[1] <- "ptrain"
  names(R2a)[2] <- "permittivity"
  la <- lm(permittivity~.,R2a)
  r2_train[1,a] <- as.numeric(summary(la)["r.squared"]) # R2 of the training data set
  
  
  ptest <- predict(temp.svr, testset)
  rmse_test[1,a] <- rmse(testset$permittivity,ptest) # RMSE of the testing data set
  
  R2b <- matrix(0, nrow = length(ptest), ncol = 2)
  R2b[,1] <- ptest
  R2b[,2] <- testset$permittivity
  R2b <- as.data.frame(R2b)
  names(R2b)[1] <- "ptest"
  names(R2b)[2] <- "permittivity"
  lb <- lm(permittivity~.,R2b)
  r2_test[1,a] <- as.numeric(summary(lb)["r.squared"]) # R2 of the testing data set

  
  # prediction of the testing set (did not involve in the current model training)
  pp <- as.matrix(ptest)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] =NA}
    
    k = k+1
  }
  
  # prediction of the training set (did not involve in the current model training)
  pp <- as.matrix(ptrain)
  k=1
  for (k in c(1:L)){
    if (k %in% row.names(pp)) {pred2[k,a] = pp[row.names(pp) == k]}
    else {pred2[k,a] =NA}
    
    k = k+1
  }
  
  print(paste('已完成：', a))
  
  a = a+1
}

ad <- "## change the file path ##"                       # change the ##output file path## into the real output file path

write.csv(rmse_train, paste(ad, "rmse_train.csv"))
write.csv(r2_train, paste(ad, "r2_train.csv"))
write.csv(rmse_test, paste(ad, "rmse_test.csv"))
write.csv(r2_test, paste(ad, "r2_test.csv"))
write.csv(pred, paste(ad, "svr_rbf_pred_test.csv"))
write.csv(pred2, paste(ad, "svr_rbf_pred_train.csv"))

### Further processing was done by EXCEL.






