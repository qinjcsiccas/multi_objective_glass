library(Metrics)
library(e1071)

path0 <- "## change the file path ##"
file_name <- "YM.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "modulus"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row

dataset <- data
head(dataset)


# create the output matrices
rmse_train <- matrix(0, nrow = 1, ncol = 10) 
r2_train <- matrix(0, nrow = 1, ncol = 10)
rmse_test <- matrix(0, nrow = 1, ncol = 10)
r2_test <- matrix(0, nrow = 1, ncol = 10)

bc = 0.005
AR = seq(0.01, 0.07, bc)
AC = c(2^-7, 2^-6, 2^-5, 2^-4, 2^-3, 2^-2, 2^-1, 1, 2^1, 2^2, 2^3, 2^4, 2^5, 2^6, 2^7, 2^8) 
# 2^-9, 2^-8, 2^-7, 2^-6, 2^-5, 2^-4, 2^-3, 2^-2, 2^-1, 1, 2^1, 2^2, 2^3, 2^4, 2^5, 2^6, 2^7, 2^8, 2^9, 2^10

NR = length(AR)
NC = length(AC)


aver1_tr <- matrix(0, nrow = NR, ncol = NC)    
aver2_tr <- matrix(0, nrow = NR, ncol = NC)
aver1_te <- matrix(0, nrow = NR, ncol = NC)
aver2_te <- matrix(0, nrow = NR, ncol = NC)


# 生成输出文件夹
ad <- "## change the file path ##\\ML\\svr_rbf\\svr_rbf_modulus_temp\\"
dir.create(paste(ad, 'aver1_tr', sep =''))
dir.create(paste(ad, 'aver2_tr', sep =''))
dir.create(paste(ad, 'aver1_te', sep =''))
dir.create(paste(ad, 'aver2_te', sep =''))

ad1 = paste(ad, 'aver1_tr\\', sep ='')
ad2 = paste(ad, 'aver2_tr\\', sep ='')
ad3 = paste(ad, 'aver1_te\\', sep ='')
ad4 = paste(ad, 'aver2_te\\', sep ='')
  
# grid search method + 10 fold cross-validation
tt = 1
t = 1

# optimized ntree + mtry
# gamma = 0.005
# cost = 2^-9
tt = 1
t = 1
for (tt in c(1:50)){
  for (gamma in AR){ 
    r = (gamma-AR[1])/bc+1
    for (cost in AC){
      for (t in c(1:10)){
        set.seed(tt)
        par1 <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
        train1 <- dataset[par1==1,]
        test1 <- dataset[par1==2,]
        
        par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
        train <- train1[par != t,]
        test <- train1[par == t,]

        temp.svr <- svm(modulus ~. , train, gamma = gamma, cost = cost, 
                   kernel ="radial")  # linear/radial/polynomial


        ### training and testing results ###
        ptrain <- predict(temp.svr, train)
        rmse_train[1,t] <- rmse(train$modulus,ptrain) # RMSE of the training data set
        
        R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
        R2a[,1] <- ptrain
        R2a[,2] <- train$modulus
        R2a <- as.data.frame(R2a)
        names(R2a)[1] <- "ptrain"
        names(R2a)[2] <- "modulus"
        la <- lm(modulus~.,R2a)
        r2_train[1,t] <- as.numeric(summary(la)["r.squared"]) # R2 of the training data set
        
        
        ptest <- predict(temp.svr, test)
        rmse_test[1,t] <- rmse(test$modulus,ptest) # RMSE of the testing data set
        
        R2b <- matrix(0, nrow = length(ptest), ncol = 2)
        R2b[,1] <- ptest
        R2b[,2] <- test$modulus
        R2b <- as.data.frame(R2b)
        names(R2b)[1] <- "ptest"
        names(R2b)[2] <- "modulus"
        lb <- lm(modulus~.,R2b)
        r2_test[1,t] <- as.numeric(summary(lb)["r.squared"]) # R2 of the testing data set
        

 
        c = (log2(cost)-log2(AC[1]))+1
        aver1_tr[round(r),c] = mean(rmse_train[1,])
        aver2_tr[round(r),c] = mean(r2_train[1,])
        aver1_te[round(r),c] = mean(rmse_test[1,])
        aver2_te[round(r),c] = mean(r2_test[1,])
          
        
        
        t = t + 1
    }
  }
}
  

  write.csv(aver1_tr,paste(ad1,tt," aver1_tr.csv", sep = ''))
  write.csv(aver2_tr,paste(ad2,tt," aver2_tr.csv", sep = ''))
  write.csv(aver1_te,paste(ad3,tt," aver1_te.csv", sep = ''))
  write.csv(aver2_te,paste(ad4,tt," aver2_te.csv", sep = ''))
  
  
  print(paste('【已完成】', '循环：', tt, '/50', sep = '')) # , '部分：', t, '/10  ',
  
  
  tt = tt + 1
  
}

### Further processing was done by EXCEL.








