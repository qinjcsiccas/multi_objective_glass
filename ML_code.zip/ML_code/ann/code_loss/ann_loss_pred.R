### artificial neural network model ###
library(nnet)
library(Metrics)

path0 <- "## change the file path ##"
file_name <- "loss.csv"
path = paste(path0, file_name, sep='')

data <- read.csv(path, encoding = "UTF-8")[,-1]
# head(data)

names(data)[dim(data)[2]] = "loss"

row <- dim(data)[1]
col <- dim(data)[2]
L <- row
l <- row

dataset <- data
head(dataset)


# create the output matrices
pred <- matrix(0, nrow = l, ncol = 1000)


for (a in c(1:1000)){
  set.seed(a)
  par <- sample(2, nrow(dataset),replace = TRUE, prob = c(0.7,0.3))
  train <- dataset[par==1,]
  test <- dataset[par==2,]
  
  set.seed(a)
  ann1=nnet(loss ~., data = train, maxit=3000,
            size = 27, decay = 0.39, linout=T, trace=F)
  # help(nnet)
  # summary(ann1)
  

  # prediction of the testing set (did not involve in the current model training)
  p <- predict(ann1, test)
  pp <- as.matrix(p)
  k=1
  for (k in c(1:l)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] = NA}
    
    k = k+1
  }
  
  a = a+1
}

ad <- "## change the file path ##"                      # change the ##output file path## into the real output file path

write.csv(pred, paste(ad, "ann_loss.csv"))


