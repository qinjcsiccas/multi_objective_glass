# install.packages("genalg")
library(foreach)
library(doParallel)
library(genalg)
library(nnet)
library(gbm)
library(randomForest)
library(Metrics)


path_file_n = "0.05\\"
# path_file_n = "0.1\\"
# path_file_n = "0.2\\"
# path_file_n = "0.05\\"


path <- paste("D:\\QJC\\多目标优化-帕累托\\output\\output_population_R_final\\", path_file_n, sep='')


fileNames <- dir(path)  ##获取该路径下的文件名
filePath <- sapply(fileNames, function(x){ 
  paste(path,x,sep='/')})   ##生成读取文件路径
data <- lapply(filePath, function(x){
  read.csv(x, header = T)})  ##读取数据，结果为list
str(data)


data_pred0 = data[[1]]
dim1 = dim(data_pred0)[1]
dim2 = dim(data_pred0)[2]

# col_prop = seq(dim2-4, dim2, 1)
data_pred = data_pred0[,-c(1)]
str(data_pred)


### 数据导出 ###
pred_out <- matrix(0, nrow = dim(data_pred)[1], ncol = 5)


### 读取已经训练好的模型 ###
path_model = 'D:\\QJC\\多目标优化-帕累托\\并行计算\\'

### 介电常数 model1 ###
load(file = paste(path_model, 'ann_permittivity_models.RData', sep=''))
model1 <- models

### 介电损耗 model2 ###
load(file = paste(path_model, 'ann_loss_models.RData', sep=''))
model2 <- models

### 热导率 model3 ###
load(file = paste(path_model, 'ann_thermalC_models.RData', sep=''))
model3 <- models

### 热膨胀系数 model4 ###
load(file = paste(path_model, 'gbdt_expansion_models_1.RData', sep=''))
model4 <- models

### 杨氏模量 model5 ###
load(file = paste(path_model, 'rf_modulus_models_1.RData', sep=''))
model5 <- models

rm(models) ##释放内存


j = 1
L = length(data)
for (j in c(1:L)){ # for (j in c(1:L)){  
  data_pred0 = data[[j]]
  dim1 = dim(data_pred0)[1]
  dim2 = dim(data_pred0)[2]

  # col_prop = seq(dim2-4, dim2, 1)
  data_pred = data_pred0[,-c(1)]
  str(data_pred)


  n_iter = 1000
  n_iter_1 = 1
  
  ### 预测暂存 ###
  pred1 <- matrix(0, nrow = 1, ncol = n_iter)
  pred2 <- matrix(0, nrow = 1, ncol = n_iter)
  pred3 <- matrix(0, nrow = 1, ncol = n_iter)
  # pred4 <- matrix(0, nrow = 1, ncol = n_iter_1)
  # pred5 <- matrix(0, nrow = 1, ncol = n_iter_1)
  
  
  for (i in c(1:dim1)){
    input_comp = data_pred[i,]
  
    for (a in c(1:n_iter)){
      pred1[1,a] = predict(model1[[a]], input_comp)
      pred2[1,a] = predict(model2[[a]], input_comp) 
      pred3[1,a] = predict(model3[[a]], input_comp) 
    }
    
    pred_out[i,1] = mean(pred1)
    pred_out[i,2] = exp(-mean(pred2))
    pred_out[i,3] = exp(mean(pred3)/10)
    pred_out[i,4] = predict(model4[[1]], input_comp)
    pred_out[i,5] = predict(model5[[1]], input_comp)
    
    print(paste("已完成： ", i, "/", dim1, sep=''))
  }
  pred_out_final = cbind(data[[j]], pred_out)
  path_out <- paste("D:\\QJC\\多目标优化-帕累托\\output\\output_population_R_final_predicted\\", path_file_n, sep='')
  write.csv(pred_out_final, file = paste(path_out, fileNames[j], sep=''))
}












