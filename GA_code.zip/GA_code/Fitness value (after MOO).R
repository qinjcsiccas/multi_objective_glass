path0 <- "## change the file path ##"
file_name1 <- "permittivity.csv"
file_name2 <- "loss.csv"
file_name3 <- "TC.csv"
file_name4 <- "CTE.csv"
file_name5 <- "YM.csv"

path1 = paste(path0, file_name1, sep='')
data1 <- read.csv(path1, encoding = "UTF-8")[,-1]

path2 = paste(path0, file_name2, sep='')
data2 <- read.csv(path2, encoding = "UTF-8")[,-1]

path3 = paste(path0, file_name3, sep='')
data3 <- read.csv(path3, encoding = "UTF-8")[,-1]

path4 = paste(path0, file_name4, sep='')
data4 <- read.csv(path4, encoding = "UTF-8")[,-1]

path5 = paste(path0, file_name5, sep='')
data5 <- read.csv(path5, encoding = "UTF-8")[,-1]


names(data1)[dim(data1)[2]] = "permittivity"
names(data2)[dim(data2)[2]] = "loss"
names(data3)[dim(data3)[2]] = "thermalC"
names(data4)[dim(data4)[2]] = "expansion"
names(data5)[dim(data5)[2]] = "modulus"

row1 <- dim(data1)[1]
col1 <- dim(data1)[2]
L1 <- row1
l1 <- row1

row2 <- dim(data2)[1]
col2 <- dim(data2)[2]
L2 <- row2
l2 <- row2

row3 <- dim(data3)[1]
col3 <- dim(data3)[2]
L3 <- row3
l3 <- row3

row4 <- dim(data4)[1]
col4 <- dim(data4)[2]
L4 <- row4
l4 <- row4

row5 <- dim(data5)[1]
col5 <- dim(data5)[2]
L5 <- row5
l5 <- row5


quartiles_1 <- quantile(data1$permittivity, probs = c(0.25, 0.5, 0.75))
quartiles_2 <- quantile(exp(-data2$loss), probs = c(0.25, 0.5, 0.75))
quartiles_3 <- quantile(exp(data3$thermalC/10), probs = c(0.25, 0.5, 0.75))
quartiles_4 <- quantile(data4$expansion, probs = c(0.25, 0.5, 0.75))
quartiles_5 <- quantile(data5$modulus, probs = c(0.25, 0.5, 0.75))

iqr1 = IQR(data1$permittivity)
iqr2 = IQR(exp(-data2$loss))
iqr3 = IQR(exp(data3$thermalC/10))
iqr4 = IQR(data4$expansion)
iqr5 = IQR(data5$modulus)

###
lb1 = min(quartiles_1) - 1.5*iqr1
ub1 = max(quartiles_1) + 1.5*iqr1
f_data1 = data1$permittivity[data1$permittivity >= lb1 & data1$permittivity <= ub1]
delta_1 = max(f_data1) - min(f_data1)

###
lb2 = min(quartiles_2) - 1.5*iqr2
ub2 = max(quartiles_2) + 1.5*iqr2
f_data2 = exp(-data2$loss)[exp(-data2$loss) >= lb2 & exp(-data2$loss) <= ub2]
delta_2 = max(f_data2) - min(f_data2)

###
lb3 = min(quartiles_3) - 1.5*iqr3
ub3 = max(quartiles_3) + 1.5*iqr3
f_data3 = exp(data3$thermalC/10)[exp(data3$thermalC/10) >= lb3 & exp(data3$thermalC/10) <= ub3]
delta_3 = max(f_data3) - min(f_data3)

###
lb4 = min(quartiles_4) - 1.5*iqr4
ub4 = max(quartiles_4) + 1.5*iqr4
f_data4 = data4$expansion[data4$expansion >= lb4 & data4$expansion <= ub4]
delta_4 = max(f_data4) - min(f_data4)

###
lb5 = min(quartiles_5) - 1.5*iqr5
ub5 = max(quartiles_5) + 1.5*iqr5
f_data5 = data5$modulus[data5$modulus >= lb5 & data5$modulus <= ub5]
delta_5 = max(f_data5) - min(f_data5)


# 归一化，避免算法偏袒某种性能：最小-最大规范化方法
weight = c(max(f_data1)/min(f_data1), 
           max(f_data2)/min(f_data2),
           max(f_data3)/min(f_data3), 
           max(f_data4)/min(f_data4),
           max(f_data5)/min(f_data5))



###########################################################################################
path0 = "D:\\QJC\\多目标优化-帕累托\\output\\output_population_R_final_predicted\\"
pathf = "0.05-5E"

path = paste(path0, pathf, sep='')

# 初始化一个空的数据框来存储结果
results <- data.frame(matrix(ncol = 1, nrow = 50))
colnames(results) <- "Sum_Last_Five_Cols"

# 遍历每个CSV文件
i = 1
for (i in c(1:50)) {
  # 构建文件名
  file_name <- paste0(path, "\\", i, "_population.csv", sep='')
  
  # 读取CSV文件，只读取最后五列
  file_data = read.csv(file_name)
  
  data <- file_data[, (ncol(file_data) - 4):ncol(file_data)]
  
  L = dim(data)[1] 
  j = 1
  for (j in c(1:L)){
    
    result = c((file_data[j, "X1"]/delta_1)^(2),
               (file_data[j, "X2"]/delta_2)^(2),
               (file_data[j, "X3"]/delta_3)^(-2),
               (file_data[j, "X4"]/delta_4)^(2),
               (file_data[j, "X5"]/delta_5)^(-2))
    results[j, i] = sum(result*weight)
  }
}


# 写入新的CSV文件
write.csv(results, paste("D:\\QJC\\多目标优化-帕累托\\output\\output_population_R_final_predicted\\", pathf, "_result.csv", sep=''))





















