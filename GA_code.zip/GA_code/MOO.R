# install.packages("genalg")
library(foreach)
library(doParallel)
library(genalg)
library(nnet)
library(gbm)
library(randomForest)
library(Metrics)


# 创建一个集群并注册
cl <- makeCluster(20)
registerDoParallel(cl)



path0 <- "## change the file path ##"
file_name1 <- "permittivity.csv"
file_name2 <- "loss.csv"
file_name3 <- "TC.csv"
file_name4 <- "CTE.csv"
file_name5 <- "YM.csv"

path1 = paste(path0, file_name1, sep='')
data1 <- read.csv(path1, encoding = "UTF-8")[,-1]

path2 = paste(path0, file_name2, sep='')
data2 <- read.csv(path2, encoding = "UTF-8")[,-1]

path3 = paste(path0, file_name3, sep='')
data3 <- read.csv(path3, encoding = "UTF-8")[,-1]

path4 = paste(path0, file_name4, sep='')
data4 <- read.csv(path4, encoding = "UTF-8")[,-1]

path5 = paste(path0, file_name5, sep='')
data5 <- read.csv(path5, encoding = "UTF-8")[,-1]


names(data1)[dim(data1)[2]] = "permittivity"
names(data2)[dim(data2)[2]] = "loss"
names(data3)[dim(data3)[2]] = "thermalC"
names(data4)[dim(data4)[2]] = "expansion"
names(data5)[dim(data5)[2]] = "modulus"

row1 <- dim(data1)[1]
col1 <- dim(data1)[2]
L1 <- row1
l1 <- row1

row2 <- dim(data2)[1]
col2 <- dim(data2)[2]
L2 <- row2
l2 <- row2

row3 <- dim(data3)[1]
col3 <- dim(data3)[2]
L3 <- row3
l3 <- row3

row4 <- dim(data4)[1]
col4 <- dim(data4)[2]
L4 <- row4
l4 <- row4

row5 <- dim(data5)[1]
col5 <- dim(data5)[2]
L5 <- row5
l5 <- row5


n_iter = 1000
n_iter_1 = 1

### 预测暂存 ###
pred1 <- matrix(0, nrow = 1, ncol = n_iter)
pred2 <- matrix(0, nrow = 1, ncol = n_iter)
pred3 <- matrix(0, nrow = 1, ncol = n_iter)



### 读取已经训练好的模型 ###
path_model = 'D:\\QJC\\多目标优化-帕累托\\并行计算\\'

### 介电常数 model1 ###
load(file = paste(path_model, 'ann_permittivity_models.RData', sep=''))
model1 <- models

### 介电损耗 model2 ###
load(file = paste(path_model, 'ann_loss_models.RData', sep=''))
model2 <- models

### 热导率 model3 ###
load(file = paste(path_model, 'ann_thermalC_models.RData', sep=''))
model3 <- models

### 热膨胀系数 model4 ###
load(file = paste(path_model, 'gbdt_expansion_models_1.RData', sep=''))
model4 <- models

### 杨氏模量 model5 ###
load(file = paste(path_model, 'rf_modulus_models_1.RData', sep=''))
model5 <- models

rm(models) ##释放内存




valence = c(1, 3, -2, -1, 1, 2, 3, 4, 5, 1, 2, 4, 3, 2, 4, 2, 2)

evaluate <- function(x){
  # 为满足“电中性”和“总摩尔百分比等于100%”，需要变换
  # population最终也需要这样处理
  ini = x*valence
  x[3] = (sum(ini) - ini[3])/2 # 氧重新赋值
  input = as.data.frame(matrix(x/sum(x)*100, nrow = 1)) # 确保总和=100
  names(input) <- names(data1)[c(1:17)]
  
  
  #### 介电常数、热导率：循环1000次
  pred_results <- foreach (a = c(1:n_iter), 
                           .export = c("model1", "model2", "model3", "pred1", "pred2", "pred3", "input"), 
                           .packages = c("genalg", "nnet", "gbm", "randomForest", "Metrics")) %dopar% {
                             
                             pred1[1,a] = predict(model1[[a]], input)
                             pred2[1,a] = exp(-predict(model2[[a]], input)) # 还原
                             pred3[1,a] = exp(predict(model3[[a]], input)/10) # 还原
                             
                             c(pred1, pred2, pred3)
                           }
  
  pred1 <- pred_results[[n_iter]][1:n_iter]
  pred2 <- pred_results[[n_iter]][(n_iter+1):(2*n_iter)]
  pred3 <- pred_results[[n_iter]][(2*n_iter+1):(3*n_iter)]
  
  
  #### 热膨胀系数、杨氏模量：不用循环，只有一个值
  pred4 = predict(model4[[1]], input)
  pred5 = predict(model5[[1]], input)
  

  
  quartiles_1 <- quantile(data1$permittivity, probs = c(0.25, 0.5, 0.75))
  quartiles_2 <- quantile(exp(-data2$loss), probs = c(0.25, 0.5, 0.75))
  quartiles_3 <- quantile(exp(data3$thermalC/10), probs = c(0.25, 0.5, 0.75))
  quartiles_4 <- quantile(data4$expansion, probs = c(0.25, 0.5, 0.75))
  quartiles_5 <- quantile(data5$modulus, probs = c(0.25, 0.5, 0.75))
  
  iqr1 = IQR(data1$permittivity)
  iqr2 = IQR(exp(-data2$loss))
  iqr3 = IQR(exp(data3$thermalC/10))
  iqr4 = IQR(data4$expansion)
  iqr5 = IQR(data5$modulus)
  
  ###
  lb1 = min(quartiles_1) - 1.5*iqr1
  ub1 = max(quartiles_1) + 1.5*iqr1
  f_data1 = data1$permittivity[data1$permittivity >= lb1 & data1$permittivity <= ub1]
  delta_1 = max(f_data1) - min(f_data1)
  
  ###
  lb2 = min(quartiles_2) - 1.5*iqr2
  ub2 = max(quartiles_2) + 1.5*iqr2
  f_data2 = exp(-data2$loss)[exp(-data2$loss) >= lb2 & exp(-data2$loss) <= ub2]
  delta_2 = max(f_data2) - min(f_data2)
  
  ###
  lb3 = min(quartiles_3) - 1.5*iqr3
  ub3 = max(quartiles_3) + 1.5*iqr3
  f_data3 = exp(data3$thermalC/10)[exp(data3$thermalC/10) >= lb3 & exp(data3$thermalC/10) <= ub3]
  delta_3 = max(f_data3) - min(f_data3)
  
  ###
  lb4 = min(quartiles_4) - 1.5*iqr4
  ub4 = max(quartiles_4) + 1.5*iqr4
  f_data4 = data4$expansion[data4$expansion >= lb4 & data4$expansion <= ub4]
  delta_4 = max(f_data4) - min(f_data4)
  
  ###
  lb5 = min(quartiles_5) - 1.5*iqr5
  ub5 = max(quartiles_5) + 1.5*iqr5
  f_data5 = data5$modulus[data5$modulus >= lb5 & data5$modulus <= ub5]
  delta_5 = max(f_data5) - min(f_data5)
  
  
  
  
  # 分子：（预测值 - 最小值） - (目标值 - 最小值)
  numerator_1 = mean(pred1[pred1!=0]) #- min(f_data1)
  numerator_2 = mean(pred2[pred2!=0]) #- min(f_data2)
  numerator_3 = mean(pred3[pred3!=0]) #- min(f_data3)
  numerator_4 = mean(pred4) #- min(f_data4)
  numerator_5 = mean(pred5) #- min(f_data5)
  
  
  # 归一化，避免算法偏袒某种性能：最小-最大规范化方法
  weight = c(max(f_data1)/min(f_data1), 
             max(f_data2)/min(f_data2),
             max(f_data3)/min(f_data3), 
             max(f_data4)/min(f_data4),
             max(f_data5)/min(f_data5))
  
  objective_value = c(0, 0, 0, 0, 0)
  
  
  
  # 五种性能
  result = c((numerator_1/delta_1)^(2),            # 介电常数，求最小值
             (numerator_2/delta_2)^(2),            #介电损耗，求最小值
             (numerator_3/delta_3)^(-2),                                 #热导率，求最大值
             (numerator_4/delta_4)^(2),            #热膨胀系数，求最小值
             (numerator_5/delta_5)^(-2)                                  #杨氏模量，求最大值
  )
  
  moo = sum(result*weight)               
  
  return (moo)
}





monitor <- function(obj) {
  #### 输出 ####
  path00 = "D:\\QJC\\多目标优化-帕累托\\output-200_4\\"
  path01 = paste(path00, "output_population\\", sep='')
  path02 = paste(path00, "output_best\\", sep='')
  
  dir.create(paste(path01, obj$mutationChance, "\\", sep = ''))
  dir.create(paste(path02, obj$mutationChance, "\\", sep = ''))
  path001 = paste(path01, obj$mutationChance, "\\", sep = '')
  path002 = paste(path02, obj$mutationChance, "\\", sep = '')
  
  
  population_n = as.numeric(length(dir(path001)))+1
  write.csv(obj$population, file = paste(path001, population_n, "_population.csv", sep=''))
  
  best_n = as.numeric(length(dir(path002)))+1
  write.csv(obj$best, file = paste(path002, best_n, "_best.csv", sep=''))
  
  print(paste("已完成第： ", best_n, " 个循环", sep = ''))
}


### Mg-Al-B-Si-O ###
Li = 0 	
B = 100 
O = 0 	
F = 0 	  # 不讨论F离子
Na = 0 	
Mg = 100 	
Al = 100 
Si = 100 
P = 0
K = 0
Ca = 0
Ti = 0
Fe = 0
Sr = 0
Zr = 0
Ba = 0
Pb = 0
max_ratio = c(Li, B, O, F, Na, Mg, Al, Si, P, K, Ca, Ti, Fe, Sr, Zr, Ba, Pb)


#对比不同mutationChance
set.seed(999)
rbga.results = rbga(stringMin=rep(0,(col1-1)), 
                    stringMax=max_ratio, 
                    popSize=200, iters=50, # popSize=100, 50
                    # elitism = NA,
                    monitorFunc = monitor,
                    evalFunc=evaluate, 
                    mutationChance=0.1, 
                    verbose=TRUE)



# 关闭集群
stopImplicitCluster()
stopCluster(cl)




