### 成分变换 ###

path_file = "0.05"
path = paste("D:\\QJC\\多目标优化-帕累托\\output\\output_population_R\\", path_file, sep='')

path0 <- "D:\\QJC\\多目标优化-帕累托\\multi-property\\"
file_name1 <- "10GHz介电常数.csv"
path1 = paste(path0, file_name1, sep='')
data1 <- read.csv(path1, encoding = "UTF-8")[,-1]

path_out_0 = 'D:\\QJC\\多目标优化-帕累托\\output\\output_population_R_final\\'
path_out = paste(path_out_0, path_file, sep = '')
dir.create(path_out)

fileNames <- dir(path)  ##获取该路径下的文件名
filePath <- sapply(fileNames, function(x){ 
  paste(path,x,sep='/')})   ##生成读取文件路径
data <- lapply(filePath, function(x){
  read.csv(x, header = T)})  ##读取数据，结果为list

L = length(data)

valence = c(1, 3, -2, -1, 1, 2, 3, 4, 5, 1, 2, 4, 3, 2, 4, 2, 2)

i = 1
for (i in c(1:L)){
  x = data[[i]][,-1]
  ini = mapply('*', x, valence)
  x[,3] = rowSums(ini)/2 # 此时氧是0，氧重新赋值
  sum_r = matrix(rowSums(x), nrow = nrow(x), byrow = TRUE)
  output = as.data.frame(x/sum_r*100) # 确保总和=100
  names(output) <- names(data1)[c(1:17)]
  
  path_out_1 = paste(path_out, '\\', fileNames[[i]], sep='')
  
  write.csv(output, path_out_1)
}

